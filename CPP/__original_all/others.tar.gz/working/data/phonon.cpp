#include "eip_main.h"
#include <string.h>



bool inside(prec x, prec y)
{
  if (((x-d_0x)*(x-d_0x)/(l_0B*l_0B*length_0_x*length_0_x)+ (y-d_0y)*(y-d_0y)/(l_0B*l_0B*length_0_y*length_0_y))<1) return(true);
  if (((x+d_0x)*(x+d_0x)/(l_0B*l_0B*length_0_x*length_0_x)+ (y+d_0y)*(y+d_0y)/(l_0B*l_0B*length_0_y*length_0_y))<1) return(true);
  //if ((x>-d_0) && (x<d_0) && (y>-length_0_y*l_0B) && (y<length_0_y*l_0B)) return(true);
  return(false);
}
 
 //************quartic potential*****************
 /*
 prec potential(prec x, prec y) {
   prec xx=0;
   if (x>0 && y>0) xx=x*y*0;
   x=x*x-d_0*d_0;
   return(av*(y*y+x*x/(4*d_0*d_0)+xx));
 }
*/

 //****************quadratic potential***********
/*
 bool Asym_=false;		//auxillary for potential
 
 prec potential(prec x, prec y) {
   if (x>0 || Asym_) x-=d_0; else x+=d_0;
   return(av*(y*y+x*x));
 }
*/
 //****************quadratic rotated potential***********

 prec potential(prec x, prec y) {
   prec p1=(x-d_0x)*(x-d_0x)+(y-d_0y)*(y-d_0y);
   prec p2=(x+d_0x)*(x+d_0x)+(y+d_0y)*(y+d_0y);
   return(av*min(p1,p2));
 }

//**********exponential potential***************
/*
 prec potential(prec x, prec y) {
   prec vo=8*av;
   prec al=av;
   if (x<0 || Asym_) x+=d_0; else x-=d_0;
   return(vo*(1-exp(-al*(y*y+x*x))));
 }
*/

//constants defining confining potential, Zeeman coupling, spin-orbit couplings
//magnetic field and vector potential calibration

int growing=1;
prec omega_u=5.5e-3*400;
prec av=omega_u*omega_u/4.0;
prec az=(-1.474e-2),azx=(-1.474e-2),azy=(-1.474e-2);
prec ab=0.0092;
prec ad=0.0125,kappa=2.963;
prec ad3=0.0031*0;
prec B=0,x_A=0,y_A=0;	   //magnetic field && calibration of the potential
prec phi_B=0,theta_B=0;
prec B_osc=1e-3/2.625,phi_osc_B=0,theta_osc_B=0*M_PI/2;
prec E_osc=1000/1.4436e+5,phi_osc_E=0*M_PI/180,theta_osc_E=M_PI/2;


//constants defining geometry (lengths) of the region

prec l_0B;		  //physical length: l_0B^-2=sqrt(B^2/4+av)
prec length_0_x=5.0;	  //how big is the region
prec length_0_y=5.0;
prec length_x,length_y;
prec dLx0=0,dLy0=0,dLx,dLy;
prec d_0=0,d_0x,d_0y,d_0_angle=0;//distance/2 of the potentials minima in a double well
int dim_x,dim_y,dim_0;

//constants for transition rate
prec width_z=11/15.8;
prec temperature=0;
int tab_nx,tab_ny;
//prec hx,hy,kxo,kyo;


//#define DRAW		//any drawing of wavefunction?
#define ERASE		//erase all files at the start?
//#define APPENDIX	//put appendix to filenames?
//#define LEVELS	//analytical formulas instead of measurement?
#define PARITY_SORTING  //sorting according to parity?
//#define MINIMIZING	//looking for minimum in spin?
//#define POWER_LAW  4    //measure dependency on the so couplings?
//#define POWER_LAW_B 4    //dependency on mag. field(theta and az)
//#define SO_CONT 7
//#define FUNCTION_PERT 1 //analytical approx (0:  FD, 1: +Hop)
//#define ENERGY_PERT 0   //analytical energies  (0:  FD, 1: +2.pert.)
#define DEPHASING 
#define DEPHASING1

#ifdef DRAW
  #define NF 4
#else //DRAW
  #define NF 2
#endif //DRAW

#ifdef FUNCTION_PERT
#ifdef ENERGY_PERT
#define NO_COMPUT
#endif
#endif

reg1::operators_precision op_prec=reg1::eight;
bool op_sym=(bool) 1;
bool op_rmmbr[reg1::all_op]={false};

int main()
{

  prec E,lv;
  FILE *file[5];
  
  
    //cTraceOn(0,0,1,0,0,0,0,0,0);
  
  char filename[5][100];
  
  char dir[]="data/";
  char name[5][100]={"measuredA","measuredB","fnc","fnc2","log"};
  bool open_log_file=true;

  #ifdef ERASE
  for (int i=0;i<5;i++) {
    strcpy(filename[i],dir); 
    strcat(filename[i],name[i]);
    if (i<NF or i==4) {
      file[i]=fopen(filename[i],"w"); 
      fclose(file[i]);
    }
  }
  #endif //ERASE
 
  
  int eig=6,eigmax=10,dimstep=1,N=1; 
  dim_0=30;dim_x=0;dim_y=0;E=-20;lv=32;
  B=(1e-2*0+1)/2.625;theta_B=1*M_PI/2;phi_B=90*M_PI/180;
  d_0=47.1/15.8;d_0_angle=0*M_PI/180;
  //signature * sig=new signature[eig];
  prec ad_old=ad,ab_old=ab,ad3_old=ad3;
  
  bool first=true, reset=true;
  open_log_file=true;

  prec step_max=1,step_min=0.1;
  prec step=step_min;
  acr_stack watch_dog;

  
  //prec step_B=2e+3;
  for (B=(1+1e-6)/2.625;B<10.1/2.625;B+=(1e+20)*step/2.625) {
    /*if (B*2.625>1e-4) {step_max=step_min=1e-4;}
    if (B*2.625>1e-3) {step_max=step_min=1e-3;}
    if (B*2.625>1e-2) {step_max=step_min=1e-2;}
    if (B*2.625>1e-1) step_max=1e-1;/*
    if (B*2.625>5) eig=6;
    if (B*2.625>6.5) eig=8;
    if (B*2.625>8) eig=9;
    if (B*2.625>9) eig=10;
    if (B*2.625>9.5) eig=11;*/
  
    prec B_aux=B;


    //for (B=(1e-1+0)/2.625;B<10.1/2.625;B+=step/2.625) {
    for (d_0=0.01/15.8;d_0<150/15.8;d_0+=step/15.8) {
      prec d_0_aux=d_0;
      if (reset) {
        d_0=10/15.8;
        B=0.1/2.625;
      }
      if (d_0*15.8>50) step_min=0.001;
      /*for (int par=0;par<181;par+=1) {{
      phi_B=par*M_PI/180;*/
      
      
      int watch_dog_pntr=0;

restart:
    
#ifdef SO_CONT
    prec val[8][7][20];
  
    for (int pr=0;pr<SO_CONT;pr++) {
      ab=ad3=ad=0;
      switch (pr) {
        case (0): {break;}
        case (1): {ad=ad_old;break;}
        case (2): {ab=ab_old;break;}
        case (3): {ad3=ad3_old;break;}
        case (4): {ad=ad_old;ab=ab_old;break;}
        case (5): {ad=ad_old;ad3=ad3_old;break;}
        case (6): {ab=ab_old;ad3=ad3_old;break;}
      }
    
#endif //SO_CONT


#ifdef POWER_LAW
    prec val[8][11][13][20]={0};
  
    for (int xx=1;xx<11;xx+=1) {
    prec x=(double)xx/1000;
    for (int pr=0;pr<POWER_LAW;pr++) {
      ad=ab=ad3=0;
      if (xx>1 && pr==0) continue;
      switch (pr) {
        case (0): {break;}
        case (1): {ad=x;break;}
        case (2): {ab=x;break;}
        case (3): {ad3=x;break;}
        case (4): {ad=x;ab=0.1;break;}
        case (5): {ad=0.1;ab=x;break;}
        case (6): {ad=0.1;ad3=x;break;}
        case (7): {ad=x;ad3=0.1;break;}
        case (8): {ad3=x;ab=0.1;break;}
        case (9): {ab=x;ad3=0.1;break;}
        //case (10): {ab=0.1;ad3=0.1;ad=x;break;}
        //case (11): {ab=x;ad3=0.1;ad=0.1;break;}
        //case (12): {ab=0.1;ad=0.1;ad3=x;break;}
      }
#endif //POWER_LAW

#ifdef POWER_LAW_B
    for (int xx=1;xx<51;xx+=1) {
      prec x=(double)xx/2000;
      for (int pr=0;pr<POWER_LAW_B;pr++) {
        ad=ab=ad3=az=0;
        if (xx>1 && pr==0) continue;
        switch (pr) {
          case (0): {az=-0.01474;break;}
          case (1): {ad=ad_old;az=-x;break;}
          case (2): {ab=ab_old;az=-x;break;}
          case (3): {ad3=ad3_old;az=-x;break;}
        }
#endif //POWER_LAW_B


    recompute_constants(E,lv,dim_0);	//E=i x 10^4 V cm^-1, lv=... nm
    //prec param_out=lv*0+B*2.625;
    prec param_out=d_0*15.8*2;

    char app[20]="",app2[20]="";
#ifdef APPENDIX
    //itoa((int) round(lv*10),app2);
    itoa((int) round(B*2.625*1000),app2);
    strcat(app2,"_T");
    strcat(app,app2);
#endif //APPENDIX

     
    
      filename[2][0]=0;filename[3][0]=0;
      for (int i=0;i<NF;i++) {
        strcpy(filename[i],dir);
        strcat(filename[i],name[i]);
        strcat(filename[i],app);
        if (!reset) file[i]=fopen(filename[i],"a");
      }
    
    if (!reset && open_log_file) {
      strcpy(filename[4],dir);
      strcat(filename[4],name[4]);
      strcat(filename[4],app);
      other_name(filename[4]);
      open_log_file=false;
    }
    


#ifdef LEVELS
    sprintf(buffer,"%e ",param_out);
    splachni(file[0],buffer,2);
    levels(file[0],2,31,eig,3,8,16,true);
#else //LEVELS


    info(logg,1+4,eig,N,dimstep);
    sprintf(buffer,"files opened: * %s * %s * %s * %s * %s *\n", filename[0],filename[1],filename[2],filename[3],filename[4]);
    splachni(logg,buffer,1+2);

#ifdef POWER_LAW
    if (xx==0)
#endif
#ifdef POWER_LAW_B
    if (xx==0)
#endif
#ifdef SO_CONT
    if (pr==0)
#endif
    
    {
      if (! reset)
      {
        sprintf(buffer,"%e ",param_out);
        splachni(file[0],buffer,1+2);
#ifndef DEPHASING
        splachni(file[1],buffer,2);
#endif
#ifdef DEPHASING1
        splachni(file[1],buffer,2);
#endif
      }
    }

    ret_from_arpack_zn vysl;
    ret_from_arpack_zn *res;

    reg1 r1(dim_x+dimstep*(N-1),dLx-length_x,2*length_x,false,dim_y+dimstep*(N-1),dLy-length_y,2*length_y,false,inside);
    //r1.ant();

    r1.act_prec_set(op_prec);
    r1.symetrize_ops(op_sym);

    vysl.eigenvecs=new content[2*r1.Nw*eig];
    vysl.eigenvals=new content[eig];


#ifndef MINIMIZING

#ifndef NO_COMPUT
       //anal_spectrumDD(vysl,r1,eig,d_0);
    int time= fitvalues(eig,N,(op_prec+1)*2,2,dim_x,dim_y,dimstep,&vysl,logg,0);
    sort_0(2*r1.Nw,eig,&vysl,true,1);
    fit_the_phase(vysl,r1,eig,3,1e-3,logg,0);
#endif

#ifdef PARITY_SORTING
    prec sens_acr=2;
    prec sort_tough=0.1;
    if (d_0>-1/2.625) sens_acr=0.95;
    if (first) {
      res=sort_after_parity(vysl,r1,eig,eigmax,sort_tough,-2,true,logg,4);
      first=false;
      if (reset) {
        reset=false;
        d_0=d_0_aux;
        B=B_aux;
        goto restart;
      }
    }
    else res=sort_after_parity(vysl,r1,eig,eigmax,sort_tough,-2,false,logg,4);
    vysl.eigenvecs=res->eigenvecs;
    vysl.eigenvals=res->eigenvals;
    //if (pr==2) {
    prec spin=statistics(vysl,r1,eigmax,4,2,logg,0,4,1);
    watch_dog.another_in(watch_dog_pntr,param_out,spin,3,0,"1-spin");
    watch_dog_pntr++;


#else  //PARITY SORTING
    eigmax=eig;
#endif //PARITY SORTING


#ifdef ENERGY_PERT
    level(-1,0,eig,eig,eig,0);
    for (int i=0;i<eig;i++) {
      int n,l,s;
      level(i+1,0,n,l,s,0);
      prec en=energy(n,l,s);
      if (ENERGY_PERT==1) {
        en+=correction(1,n,l,s);
        en+=correction(2,n,l,s);
      }
      vysl.eigenvals[i]=content(en,0);
    }
#endif //ENERGY_PERT
  
#ifdef FUNCTION_PERT
    level(-1,0,eig,eig,eig,0);
    content* aux=new content[r1.Nw*2];
    for (int i=0;i<eig;i++) {
      content *pntr=vysl.eigenvecs+r1.Nw*2*i;
      int n,l,s,spin=0;
      if (s==-1) spin=1;
      level(i+1,0,n,l,s,0);
      anal_function(r1,aux,n,l,s,d_0, 1, reg1::set);
      r1.operate(aux,pntr,0,0,reg1::lin_com,content(1,0),0,reg1::set);
      r1.operate(aux,pntr,1,1,reg1::lin_com,content(1,0),0,reg1::set);
      if (FUNCTION_PERT==1) {
        r1.operate(aux,pntr,1,0,reg1::lin_com,content(ab/2,ad/2),xc,reg1::add);
        r1.operate(aux,pntr,0,1,reg1::lin_com,content(-ab/2,ad/2),xc,reg1::add);
        r1.operate(aux,pntr,1,0,reg1::lin_com,content(-ad/2,-ab/2),yc,reg1::add);
        r1.operate(aux,pntr,0,1,reg1::lin_com,content(ad/2,-ab/2),yc,reg1::add);
      }
      norm_function(r1,pntr);
    }
#endif //FUNCTION_PERT


#else //MINIMIZING
{
    prec step=2*ab, step_max=5*ab;
    prec spin=0,old=0;
    bool first=true;
    int whicheig=1;
    //d_0-=step;
    B-=step;
    do {
      //d_0+=step;
      B+=step;
      recompute_constants(E,lv,dim_0);	//E=i x 10^4 V cm^-1, lv=... nm
      int time= fitvalues(eig,N,(op_prec+1)*2,2,dim_x,dim_y,dimstep,&vysl,logg,4);
      sort_0(2*r1.Nw,eig,&vysl,true,1);
      spin=statistics(vysl,r1,eig,4,0,logg,0,4,whicheig);
      printf("at param B=%f spin of %i eigvec = %e\n",B*2.625,whicheig,spin);
      if (first) first=false;
      else {
        step*=-spin/(spin-old);
        //if (spin*old>0) {if (fabs(spin)>fabs(old)) step*=-1;}
	//else step*=-0.5;
	if (fabs(step)>step_max) step*=step_max/fabs(step);
	if (spin*old>0 && spin*old>1-5*ad) step/=2;
      }
      old=spin;
    }
    while (fabs(spin)>1e-2);
    //d_0-=step;
    B-=step;
}
#endif //MINIMIZING
    for (int i=0;i<eigmax;i++) {
      prec ei=vysl.eigenvals[i].real();
      if (ei>1000) continue;
      prec min=1e+5;
      for (int j=0;j<eigmax;j++) {
        if (j==i) continue;
        prec ej=vysl.eigenvals[j].real();
        if (min>fabs(ei-ej)) min=fabs(ei-ej);
      }
      
        char name[100];
        sprintf(name,"%i ",i);
          
        //energy difference (normal) - quadratic approx
        watch_dog.another_in(watch_dog_pntr,param_out,min,3,0,strcat(name,"energy"));
        watch_dog_pntr++;
        
        //only linear approximation !!!
        watch_dog.another_in(watch_dog_pntr,param_out,min,3,1,strcat(name," der."));
        watch_dog_pntr++;
    }

    int what_picked=32+0*8192*(1+2);
    int what_all=4+8+32+1024*(4);
    
    prec rates[8*eigmax];
    
    prec tun=(vysl.eigenvals[2]-vysl.eigenvals[0]).real();
    prec zem=(vysl.eigenvals[1]-vysl.eigenvals[0]).real();
    sprintf(buffer,"%e ",tun*2.25);
    splachni(file[0],buffer,2);
    splachni(file[1],buffer,2);
 
#ifdef DEPHASING

    prec omega=(vysl.eigenvals[1].real()-vysl.eigenvals[0].real());
    omega*=3.45e+12*1.0000001;
    //omega=1e+6*1.00001*2*M_PI;
    prec *rho=new prec[eigmax];
    statistics(vysl, r1, eigmax, what_all,1+4+8 ,file[1], 4);

#ifdef DEPHASING1 
 
    if (what_picked>0) statistics(vysl, r1, eigmax, what_picked, 2+8, file[1], 2);

    int base=4;
    struct rates *r;
    r=fill_rates(vysl, r1, base);
    prec *result=new prec[19*base*(base-1)/2];
    int pntr=0;
    
    for (int i=0;i<base;i++) {
      for (int j=i+1;j<base;j++) {
        scan(r, i, j,result+pntr, file[0], 2, 0, 1e-10);
        if (j<4) {//for four lowest states
          //field element
          char name[100];
          sprintf(name,"%i-%i field",i,j);
          watch_dog.another_in(watch_dog_pntr,param_out,(result+pntr)[10],3,0,name);
          watch_dog_pntr++;
        }
        pntr+=19;
      }
    }
    pntr=0;
    for (int i=0;i<19*base*(base-1)/2;i++) {
      prec aux=result[i];
      if (isnan(aux) || isinf(aux)) {
        aux=-0.0;pntr++;
      }
      sprintf(buffer,"%e ",aux);
      splachni(file[0],buffer,2);
    }
    message(file[0],"\n",2);
    sprintf(buffer,"\ntotal %i numbers ill defined\n\n",pntr);
    if (pntr>0) splachni(logg,buffer,1+4);


    //sprintf(buffer,"%e %e",left, right);
    //splachni(file[0],buffer,2);

     
#else  //DEPHASING1 
    
    int base=4;
    prec stepmax=1e+5;
    content *rho=new content[base*base];
    rho[0*2+0]=content(1,0);
    rho[1*2+1]=content(0,0);
    rho[0*2+1]=content(0,0);
    rho[1*2+0]=content(0,0);


     derivs* d;
     d=fill_derivs(vysl,r1,base);
     fill_derivs2(d,omega,1,0);
     find_equilibrium(d,omega,rho,stepmax,file[1],0);
     prec a=absorption(d,rho);
     exit(0);
     
#endif //DEPHASING1
     
#else //DEPHASING
    
    if (what_all>0) statistics(vysl, r1, eigmax, what_all,1+4+8, logg, 1+4);
    if (what_picked>0) statistics(vysl, r1, eigmax, what_picked, 2+8, file[1], 2);
    
    transition_rates(vysl,r1,eigmax, rates, 4);
#endif //DEPHASING

    
    step=watch_dog.adjust_step(param_out,step_min,step_max,5*2);
    //if (tun<1e-12) d_0=87.0999/15.8;
    
#ifndef SO_CONT
#ifndef POWER_LAW
#ifndef POWER_LAW_B
#ifndef DEPHASING
    
   
    for (int i=0;i<8*eigmax;i++) {
      sprintf(buffer,"%e ",rates[i]);
      splachni(file[0],buffer,2);
    }
    message(file[0],"\n",2);

#endif //DEPHASING
#endif //POWER_LAW_B
#endif //POWER_LAW
#endif //SO_CONT

#ifdef POWER_LAW_B
      if (pr==1) {
        fprintf(file[0],"%e ",x);
      }
        for (int i=0;i<eigmax;i++) {
          for (int w=0;w<8;w++) { 
            sprintf(buffer,"%e ",rates[i*8+w]);
            splachni(file[0],buffer,2);
          }
        }
        if (pr==POWER_LAW_B-1) message(file[0],"\n",2);
#endif //POWER_LAW_B

#ifdef POWER_LAW
    
    for (int i=0;i<eigmax;i++) {
      for (int w=0;w<8;w++) {
        val[w][xx][pr][i]=rates[i*8+w];
      }
    }
#endif

#ifdef SO_CONT
    for (int i=0;i<eigmax;i++) {
      for (int w=0;w<8;w++) {
        val[w][pr][i]=rates[i*8+w];
      }
    }
#endif


#ifdef DRAW
    content* &pntr=vysl.eigenvecs;
    for (int i=0;i<eigmax;i++) {
      content* in=pntr+2*i*r1.Nw;
      r1.draw(in,0,1,file[2],2);
      r1.draw(in,1,1,file[2],2);
    }
#endif //DRAW
    delete vysl.eigenvecs;
    delete vysl.eigenvals;
#endif //LEVELS
    for (int j=0;j<NF;j++) fclose(file[j]);

#ifdef POWER_LAW_B
    }
#endif

  }
#ifdef POWER_LAW
    }

  file[0]=fopen(filename[0],"a");

  for (int xx=1;xx<11;xx++) {
    for (int pr=0;pr<POWER_LAW;pr++) {
      for (int i=0;i<eigmax;i++) {
        for (int w=0;w<8;w++){
          if (pr==0) val[w][xx][0][i]=val[w][1][0][i];
          if (pr>0) val[w][xx][pr][i]-=val[w][1][0][i];
        }
      }
    }
  }
  for (int xx=1;xx<11;xx+=1) {
    fprintf(file[0],"%e\t",(double) xx/1000);
    for (int pr=0;pr<POWER_LAW;pr++) {
      for (int i=0;i<eigmax;i++) {
        for (int w=0;w<11;w++) {
          prec vys=val[w][xx][pr][i];
  
          switch (pr) {
            case (0) :{;break;}
            case (1) :{;break;}
            case (2) :{;break;}
            case (3) :{;break;}
            case (4) :{vys-=val[w][xx][1][i]+val[w][10][2][i];break;}
            case (5) :{vys-=val[w][xx][2][i]+val[w][10][1][i];break;}
            case (6) :{vys-=val[w][xx][3][i]+val[w][10][1][i];break;}
            case (7) :{vys-=val[w][xx][1][i]+val[w][10][3][i];break;}
            case (8) :{vys-=val[w][xx][3][i]+val[w][10][2][i];break;}
            case (9) :{vys-=val[w][xx][2][i]+val[w][10][3][i];break;}
            //case (10) :{vys-=en[xx][4][i]+en[10][8][i]+en[xx][7][i]-en[xx][1][i]-en[10][2][i]-en[10][3][i];break;}
            //case (11) :{vys-=en[xx][5][i]+en[xx][9][i]+en[10][6][i]-en[10][1][i]-en[xx][2][i]-en[10][3][i];break;}
            //case (12) :{vys-=en[10][5][i]+en[xx][8][i]+en[xx][6][i]-en[10][1][i]-en[10][2][i]-en[xx][3][i];break;}
            default : {printf("what the fk??\n");return(1);}
          }
          fprintf(file[0],"%e ",vys);
        } 
      } 
    }
    fprintf(file[0],"\n");
  }
  fclose(file[0]);
#endif //POWER_LAW

#ifdef SO_CONT
   
    file[0]=fopen(filename[0],"a");
    for (int pr=0;pr<SO_CONT;pr++) {
      for (int i=0;i<eigmax;i++) {
        for (int w=0;w<8;w++){
          if (pr>0) val[w][pr][i]-=val[w][0][i];
          prec vys=val[w][pr][i];
          switch (pr) {
            case (0) :{;break;}
            case (1) :{;break;}
            case (2) :{;break;}
            case (3) :{;break;}
            case (4) :{vys-=val[w][1][i]+val[w][2][i];break;}
            case (5) :{vys-=val[w][1][i]+val[w][3][i];break;}
            case (6) :{vys-=val[w][2][i]+val[w][3][i];break;}
            default : {printf("what the fk??\n");return(1);}
          }
          fprintf(file[0],"%e ",vys);
        } 
      } 
    }
    fprintf(file[0],"\n");
    fclose(file[0]);
  }
#endif //SO_CONT

    }
return(0);
}

